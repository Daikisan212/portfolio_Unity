﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class vpad : MonoBehaviour
{
    [SerializeField] int mMax = 50;
    public Vector3 Pos;

    public void ONTsD(BaseEventData e)
    {
        var ChgEdata = (PointerEventData)e;
        transform.localPosition = Vector3.ClampMagnitude(transform.localPosition + (Vector3)ChgEdata.delta,mMax);

        Pos = transform.localPosition / mMax;

        Debug.Log(Pos);
    }

    public void OnTsUp()
    {
        transform.localPosition = Vector3.zero;
        Pos = Vector3.zero;
    }

}
